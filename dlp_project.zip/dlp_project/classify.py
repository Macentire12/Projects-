import re


email_regex = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
credit_card_regex = r'\b(?:\d[ -]*?){13,16}\b'

def classify_data(text):
    emails = re.findall(email_regex, text)
    credit_cards = re.findall(credit_card_regex, text)
    return emails, credit_cards
