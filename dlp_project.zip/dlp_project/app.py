from flask import Flask, render_template, request, jsonify
import threading
import time
import os
import re
from classify import classify_data

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

incident_log_path = 'incident_log.txt'

def log_incident(message):
    with open(incident_log_path, 'a') as log_file:
        log_file.write(f"{message}\n")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/log')
def get_log():
    if os.path.exists(incident_log_path):
        with open(incident_log_path, 'r') as log_file:
            content = log_file.read()
    else:
        content = "No incidents logged yet."
    return jsonify(content=content)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify(message='No file part'), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify(message='No selected file'), 400
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        with open(file_path, 'r') as f:
            content = f.read()
            emails, credit_cards = classify_data(content)
            response_message = []
            if emails:
                response_message.append('Email addresses detected')
                log_incident(f"Sensitive data found in uploaded file: {file.filename} - Emails: {emails}")
            if credit_cards:
                response_message.append('Credit card numbers detected')
                log_incident(f"Sensitive data found in uploaded file: {file.filename} - Credit Cards: {credit_cards}")
            if not emails and not credit_cards:
                response_message.append('No sensitive data detected')
        return jsonify(message='; '.join(response_message)), 200
    return jsonify(message='File upload failed'), 400

def dlp_monitor(path):
    print("Monitoring directory:", path)
    snapshot_files = {f: os.path.getmtime(os.path.join(path, f)) for f in os.listdir(path)}
    
    while True:
        time.sleep(5)
        for f in os.listdir(path):
            full_path = os.path.join(path, f)
            
            if f not in snapshot_files:
                print(f"New file detected: {f}")
                snapshot_files[f] = os.path.getmtime(full_path)
                
                with open(full_path, 'r') as file:
                    content = file.read()
                    emails, credit_cards = classify_data(content)
                    if emails or credit_cards:
                        log_incident(f"Sensitive data found in new file: {f}")
            
            elif os.path.getmtime(full_path) != snapshot_files[f]:
                print(f"File modified: {f}")
                snapshot_files[f] = os.path.getmtime(full_path)
                
                with open(full_path, 'r') as file:
                    content = file.read()
                    emails, credit_cards = classify_data(content)
                    if emails or credit_cards:
                        log_incident(f"Sensitive data found in modified file: {f}")

if __name__ == '__main__':
    folder_path = './test'  
    monitor_thread = threading.Thread(target=dlp_monitor, args=(folder_path,))
    monitor_thread.daemon = True
    monitor_thread.start()
    app.run(debug=True)
