import time
import smtplib
from email.mime.text import MIMEText

# Enter info in strings below to get email notificationss
def send_alert(subject, body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = '   '  
    msg['To'] = ''

    with smtplib.SMTP('smtp.mail.me.com', 465) as server:
        server.starttls()
        server.login('', '')
        server.sendmail('', 'l', msg.as_string())
        print("Email  sent")

def log_incident(incident):
    with open('incident_log.txt', 'a') as log_file:
        log_file.write(f"{time.ctime()}: {incident}\n")
    send_alert("DLP Incident Detected", incident)
