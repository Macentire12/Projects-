import time
import os
from indicent import log_incident
from classify import classify_data

def dlp_monitor(path):
    
    print("Monitoring directory:", path)
    
    snapshot_files = {f: os.path.getmtime(os.path.join(path, f)) for f in os.listdir(path)}
    
    while True:
        time.sleep(5)
        for f in os.listdir(path):
            full_path = os.path.join(path, f)
            
            if f not in snapshot_files:
                print(f"New file detected: {f}")
                snapshot_files[f] = os.path.getmtime(full_path)
                
                with open(full_path, 'r') as file:
                    content = file.read()
                    emails, credit_cards = classify_data(content)
                    if emails or credit_cards:
                        log_incident(f"Sensitive data found in new file: {f}")
            
            elif os.path.getmtime(full_path) != snapshot_files[f]:
                print(f"File modified: {f}")
                snapshot_files[f] = os.path.getmtime(full_path)
                
                with open(full_path, 'r') as file:
                    content = file.read()
                    emails, credit_cards = classify_data(content)
                    if emails or credit_cards:
                        log_incident(f"Sensitive data found in modified file: {f}")

if __name__ == "__main__":
    folder_path = './green' 
    dlp_monitor(folder_path)
